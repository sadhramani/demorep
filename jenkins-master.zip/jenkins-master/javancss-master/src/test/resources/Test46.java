import foo.bar;

/**
 * Hello
 */
public class Test46 {
        /**
         * bla
         */
        public Test46() {
            super();
        }

        /**
         * something is wrong here
         */

        /* so it is */
        // bla
    /** 
         * formal javadoc comment
     */
    public static void filter()    {
        int i = 2;
    }

        /* no comment */
        public static void main(String args) {
         System.exit( 1 );
        }
}
