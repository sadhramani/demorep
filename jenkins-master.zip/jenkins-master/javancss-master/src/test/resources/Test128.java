public class Test128
{
public
@Override void update(Component component, UpdateStrategy strategy) {
    return;
}
}
