public class Test105
{
    private static final Map<Class, Format> FORMATTED_TYPES = new
        HashMap<Class, Format>();
    private static final Map<String, EnterpriseLevel> LITERAL_LEVEL_MAP =
        new HashMap<String, EnterpriseLevel>();

    public Test105(String[] asArgs_, String sRcsHeader_) {
        Test105 enum = null;
    }
}
