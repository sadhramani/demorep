public synchronized class Test29 {}
