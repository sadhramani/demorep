/**
 * This class is used to check java comment counting.
 */
public class Test68
{
    /**
     * Default formal comment for a method.
     */
    static public void main( String[] args )
    {
        // exit
        System.exit( 0 );
    }
}
