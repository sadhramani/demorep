import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

public class Java7Diamond {

    Map<Date,String> returnMap = new TreeMap<>(); 
}
